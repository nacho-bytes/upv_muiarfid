from mesa import Agent
import numpy as np

class Peaton(Agent):
    def __init__(self, unique_id, model, pos, direccion):
        super().__init__(unique_id, model)
        self.pos = np.array(pos)
        self.direccion = direccion
        self.cambios_fila = 0
        self.ultima_fila = pos[1] 
        self.velocidad = np.array([0, 0])

    def calcular_fuerza_repulsion(self):
        fuerza_total = np.array([0, 0])
        for obstaculo in self.model.obstaculos:
            distancia = np.linalg.norm(self.pos - obstaculo.pos)
            if distancia > 0:
                fuerza = (self.pos - obstaculo.pos) / distancia**2
                fuerza_total += fuerza
        return fuerza_total

    def mover_hacia_destino(self):
        direccion = self.destino - self.pos
        direccion_normalizada = direccion / np.linalg.norm(direccion)
        return direccion_normalizada

    def calcular_fuerza_repulsion_en_paso(self, paso):
        fuerza = 0
        for vecino in self.model.grid.get_neighbors(paso, moore=True, include_center=True):
            if isinstance(vecino, Obstaculo) or isinstance(vecino, Peaton):
                distancia = np.linalg.norm(np.array(paso) - np.array(vecino.pos))
                if distancia > 0:
                    fuerza += 1 / distancia**2
        return fuerza
        
    def step(self):
        x, y = self.pos
        grid_width = self.model.grid.width
        grid_height = self.model.grid.height

        #print(f"Peatón {self.unique_id} en posición {self.pos}")

        # Posiciones potenciales para moverse
        #posibles_pasos = [(x + 1, y), (x + 1, y - 1), (x + 1, y + 1), (x, y)]  # Derecha, diagonal abajo, diagonal arriba, quedarse
        if self.direccion == "derecha":
            posibles_pasos = [(x + 1, y), (x + 1, y - 1), (x + 1, y + 1), (x, y)]
        else:
            posibles_pasos = [(x - 1, y), (x - 1, y - 1), (x - 1, y + 1), (x, y)]

        posibles_pasos = [(paso[0] % grid_width, paso[1]) for paso in posibles_pasos]  # Envoltura horizontal
        posibles_pasos = [paso for paso in posibles_pasos if 0 <= paso[1] < grid_height]  # Dentro de límites verticales

        # Evaluar la fuerza de repulsión para cada paso posible
        mejor_paso = None
        menor_fuerza = float('inf')
        for paso in posibles_pasos:
            if self.model.grid.is_cell_empty(paso) and not self.hay_obstaculo_en_celda(paso):
                fuerza_repulsion = self.calcular_fuerza_repulsion_en_paso(paso)
                if fuerza_repulsion < menor_fuerza:
                    menor_fuerza = fuerza_repulsion
                    mejor_paso = paso

        # Mover al peatón al paso con menor fuerza de repulsión, si es posible
        if mejor_paso is not None:
            self.model.grid.move_agent(self, mejor_paso)
            
        if self.pos[1] != self.ultima_fila:
            self.cambios_fila += 1
            self.ultima_fila = self.pos[1]

    def hay_obstaculo_en_celda(self, celda):
        # Comprobar si hay algún obstáculo en la celda especificada
        contenido_celda = self.model.grid.get_cell_list_contents(celda)
        return any(isinstance(objeto, Obstaculo) for objeto in contenido_celda)

    def calcular_fuerza_repulsion_en_paso(self, paso):
        vecinos = self.model.grid.get_neighbors(paso, moore=True, include_center=False)
        fuerza = len(vecinos)  # Uso simplificado: más vecinos, mayor la fuerza
        return fuerza
        
class Obstaculo(Agent):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model)
        self.pos = np.array(pos)

    def step(self):
        # Los obstáculos no se mueven ni actúan
        pass