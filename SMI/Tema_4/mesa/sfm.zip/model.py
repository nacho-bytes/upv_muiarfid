from mesa import Model
from mesa.space import MultiGrid
from mesa.time import RandomActivation
from agent import Peaton, Obstaculo
from mesa import DataCollector
import random

class SocialForceModel(Model):
    def __init__(self, N, width, height, num_obstaculos):
        super().__init__()
        self.num_peatones = N
        self.num_obstaculos = num_obstaculos
        self.grid = MultiGrid(width, height, True)
        self.schedule = RandomActivation(self)
        self.obstaculos = []


        # Crear peatones
        for i in range(self.num_peatones):
            x = random.randrange(self.grid.width)
            y = random.randrange(self.grid.height)
            direccion = "derecha" if i < self.num_peatones / 2 else "izquierda"
            peaton = Peaton(i, self, (x, y), direccion)
            self.grid.place_agent(peaton, (x, y))
            self.schedule.add(peaton)

        # Crear obstáculos
        for i in range(num_obstaculos):
            x = random.randrange(self.grid.width - 1)  # -1 para dejar espacio
            y = random.randrange(self.grid.height - 1)
            
            # Crear obstáculo ocupando un área de 2x2
            for dx in range(2):
                for dy in range(2):
                    obstaculo = Obstaculo(i+N, self, (x + dx, y + dy))
                    self.grid.place_agent(obstaculo, (x + dx, y + dy))
                    self.obstaculos.append(obstaculo)
                    
        self.datacollector = DataCollector(
            model_reporters={"Total Cambios de Fila": lambda m: sum(peaton.cambios_fila for peaton in m.schedule.agents if isinstance(peaton, Peaton)),
                            "Densidades": self.calcular_densidad_por_zona_y_direccion,

            } )
        
    def calcular_densidad_por_zona_y_direccion(self):
        # Inicializar contadores para cada zona y dirección
        densidad_norte_derecha = densidad_norte_izquierda = 0
        densidad_centro_derecha = densidad_centro_izquierda = 0
        densidad_sur_derecha = densidad_sur_izquierda = 0

        zona_alta = int(self.grid.height / 3)
        zona_baja = int(self.grid.height * 2 / 3)

        for agente in self.schedule.agents:
            if isinstance(agente, Peaton):
                _, y = agente.pos
                if y < zona_alta:
                    if agente.direccion == "derecha":
                        densidad_norte_derecha += 1
                    else:
                        densidad_norte_izquierda += 1
                elif y < zona_baja:
                    if agente.direccion == "derecha":
                        densidad_centro_derecha += 1
                    else:
                        densidad_centro_izquierda += 1
                else:
                    if agente.direccion == "derecha":
                        densidad_sur_derecha += 1
                    else:
                        densidad_sur_izquierda += 1

        return {
            "norte_derecha": densidad_norte_derecha,
            "norte_izquierda": densidad_norte_izquierda,
            "centro_derecha": densidad_centro_derecha,
            "centro_izquierda": densidad_centro_izquierda,
            "sur_derecha": densidad_sur_derecha,
            "sur_izquierda": densidad_sur_izquierda
        }
                            
    def step(self):
        self.schedule.step()
        self.datacollector.collect(self)