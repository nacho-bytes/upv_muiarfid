import mesa
from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.modules import CanvasGrid
from model import SocialForceModel
from agent import Peaton, Obstaculo

def agent_portrayal(agent):
    portrayal = None
    if type(agent) is Peaton:
        if agent.direccion == "derecha":
            portrayal = {"Shape": "circle", "Filled": "true", "r": 1, "Color": "red", "Layer": 0}
        else: portrayal = {"Shape": "circle", "Filled": "true", "r": 1, "Color": "green", "Layer": 0}
    elif type(agent) is Obstaculo:
        portrayal = {"Shape": "rect", "Filled": "true", "w": 1.0, "h": 1.0, "Color": "blue", "Layer": 1}
    return portrayal

grid = CanvasGrid(agent_portrayal, 100, 20, 1000, 200)

model_params = {
        "N": mesa.visualization.Slider("Number of Peatones", 10, 1, 1000, 1),
        "width": 100,
        "height": 20,
        "num_obstaculos": mesa.visualization.Slider("Number of Obstaculos", 5, 0, 20, 1)
}

server = ModularServer(SocialForceModel,
                       [grid],
                        "Social Force Model",
                        model_params)
server.port = 8521