from mesa import Agent, Model
from mesa.time import RandomActivation
from mesa.space import MultiGrid
from mesa.datacollection import DataCollector
import random
import matplotlib.pyplot as plt

# Definición del agente SIR
class SIRAgent(Agent):
    SUSCEPTIBLE = 0
    INFECTED = 1
    RECOVERED = 2

    def __init__(self, unique_id, model, initial_state=SUSCEPTIBLE):
        super().__init__(unique_id, model)
        self.state = initial_state
        self.infection_time = 0
        self.individual_recovery_time = self.model.recovery_time + random.randint(-2, 2)
        
    def move(self):
        possible_steps = self.model.grid.get_neighborhood(
            self.pos,
            moore=True,
            include_center=False)
        new_position = self.random.choice(possible_steps)
        self.model.grid.move_agent(self, new_position)

    def step(self):
        self.move()
        if self.state == self.INFECTED:
            self.infection_time += 1
            if self.infection_time >= self.individual_recovery_time:
                self.state = self.RECOVERED
            self.try_to_infect()

    def try_to_infect(self):
        if self.state == self.INFECTED:
            neighbors_nodes = self.model.grid.get_neighbors(self.pos, moore=True, include_center=False)
            susceptible_neighbors = [agent for agent in neighbors_nodes if agent.state == self.SUSCEPTIBLE]
            for neighbor in susceptible_neighbors:
                if random.random() < self.model.infection_rate:
                    neighbor.state = self.INFECTED