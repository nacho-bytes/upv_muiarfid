from mesa import Model
from mesa.time import RandomActivation
from mesa.space import MultiGrid
from mesa.datacollection import DataCollector
from agent import SIRAgent
import random

class SIRModel(Model):
    def __init__(self, N, width, height, infection_rate, recovery_time):
        super().__init__()
        self.num_agents = N
        self.grid = MultiGrid(width, height, True)
        self.schedule = RandomActivation(self)
        self.infection_rate = infection_rate
        self.recovery_time = recovery_time

        for i in range(self.num_agents):
            a = SIRAgent(i, self)
            self.schedule.add(a)
            x = random.randrange(self.grid.width)
            y = random.randrange(self.grid.height)
            self.grid.place_agent(a, (x, y))
            infected = random.random() < 0.05
            if infected:
                a.state = a.INFECTED

        self.datacollector = DataCollector(
            model_reporters={"Susceptible": lambda m: self.count_state(m, SIRAgent.SUSCEPTIBLE),
                             "Infected": lambda m: self.count_state(m, SIRAgent.INFECTED),
                             "Recovered": lambda m: self.count_state(m, SIRAgent.RECOVERED),
                             "R0": self.calculate_R0} 
        )
        
    def calculate_R0(self):
        """ Calcular el valor de R0 en el modelo. """
        susceptibles = self.count_state(self, SIRAgent.SUSCEPTIBLE)
        if susceptibles == 0:  # Evitar división por cero
            return 0
        return (self.infection_rate * susceptibles) / (1 / self.recovery_time)


    @staticmethod
    def count_state(model, state):
        return sum([1 for agent in model.schedule.agents if agent.state == state])

    def step(self):
        self.datacollector.collect(self)
        self.schedule.step()