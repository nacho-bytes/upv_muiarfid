import mesa
from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.modules import CanvasGrid
from mesa.visualization import Slider

from model import SIRModel
from agent import SIRAgent

def agent_portrayal(agent):
    portrayal = {"Shape": "circle", "Filled": "true", "r": 0.5}
    
    if agent.state == SIRAgent.SUSCEPTIBLE:
        portrayal["Color"] = "blue"
        portrayal["Layer"] = 0
    elif agent.state == SIRAgent.INFECTED:
        portrayal["Color"] = "red"
        portrayal["Layer"] = 1
    elif agent.state == SIRAgent.RECOVERED:
        portrayal["Color"] = "green"
        portrayal["Layer"] = 2
    return portrayal

grid = CanvasGrid(agent_portrayal, 20, 20, 500, 500)

slider_number_of_agents = Slider("Number of Agents", 100, 10, 200, 1)

slider_infection_rate = Slider("Infection rate", 0.1, 0.01, 1.0, 0.01)
slider_recovery_time = Slider("Recovery time", 20, 1, 50, 1)

model_params = {
    "N": slider_number_of_agents,
    "width": 20,
    "height": 20,
    "infection_rate": slider_infection_rate,
    "recovery_time": slider_recovery_time
}

server = ModularServer(SIRModel,
                       [grid],
                       "SIR Model",
                       model_params)

if __name__ == '__main__':
    server.launch()
